var canvas = document.getElementById('canvas');
var ctx = canvas.getContext('2d');
ctx.font = '100px Arial';
ctx.strokeStyle = 'green';
ctx.fillStyle = 'pink';
ctx.lineWidth = 5;
ctx.strokeText('Konstantin', 200, 200);
ctx.fillText('Konstantin', 200, 200);


